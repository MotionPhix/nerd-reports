<template>

  <ul class="mb-12 space-y-6">

    <slot />

  </ul>

</template>
