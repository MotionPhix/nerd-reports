<template>
  <ul class="w-full divide-y divide-slate-300 dark:divide-slate-700">
    <slot></slot>
  </ul>
</template>
