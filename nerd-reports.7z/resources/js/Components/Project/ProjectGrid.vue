<template>
  <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">

    <slot></slot>

  </div>
</template>
