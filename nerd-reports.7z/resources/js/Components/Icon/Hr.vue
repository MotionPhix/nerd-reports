<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="fill-current"><title>horizontal-rule</title>
  <path d="M5,13 C4.44771525,13 4,12.5522847 4,12 C4,11.4477153 4.44771525,11 5,11 L19,11 C19.5522847,11 20,11.4477153 20,12 C20,12.5522847 19.5522847,13 19,13 L5,13 Z"/>
</svg>

</template>
