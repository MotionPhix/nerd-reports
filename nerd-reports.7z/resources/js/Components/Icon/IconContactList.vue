<template>
<svg viewBox="0 0 500 500" width="500" height="500" xmlns="http://www.w3.org/2000/svg">
  <path d="M 231.18 227.82 C 292.422 227.82 342.076 178.168 342.076 116.925 C 342.076 55.68 292.422 6.028 231.18 6.028 C 169.936 6.028 120.283 55.68 120.283 116.925 C 120.283 178.168 169.936 227.82 231.18 227.82 Z" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" fill="currentColor"/>
  <path d="M 364.255 316.537 C 413.255 316.537 453.977 359.271 426.534 399.843 C 388.71 455.734 314.513 493.972 231.18 493.972 C 147.874 493.972 73.648 455.734 35.853 399.843 C 8.381 359.271 49.103 316.537 98.104 316.537 L 364.255 316.537 Z" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="currentColor"/>
  <line class="st0" x1="393.073" y1="213.612" x2="473.016" y2="213.612" style="fill: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;" stroke-width="3em" stroke="currentColor"/>
  <line class="st0" x1="389.259" y1="263.764" x2="435.892" y2="263.764" style="fill: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10;" stroke-width="3em" stroke="currentColor"/>
</svg>
</template>
